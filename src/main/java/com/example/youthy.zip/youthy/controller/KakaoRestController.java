package com.example.youthy.controller;

import com.example.youthy.config.CurrentMember;
import com.example.youthy.domain.Member;
import com.example.youthy.dto.Tokens;
import com.example.youthy.repository.MemberRepository;
import com.example.youthy.service.KakaoService;
import com.example.youthy.service.TokenService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RequiredArgsConstructor
@RestController
@RequestMapping("/kakao")
public class KakaoRestController {

    private final KakaoService kakaoService;
    private final TokenService tokenService;
    private final MemberRepository memberRepository;

    // GET /kakao/callback?code=...
    @GetMapping("/callback")
    public ResponseEntity<?> callback(@RequestParam("code") String code,
                                      HttpServletRequest req,
                                      HttpServletResponse res) {
        try {
            String accessTokenFromKakao = kakaoService.getAccessToken(code);
            Map<String, Object> userInfo = kakaoService.getUserInfo(accessTokenFromKakao);

            // 회원 가입 or 업데이트
            Tokens tokens = kakaoService.processUser(userInfo);

            // refresh 토큰을 HttpOnly 쿠키로 내려주기
            setRefreshCookie(res, tokens.getRefresh());

            return ResponseEntity.ok(Map.of(
                    "status", "success",
                    "accessToken", tokens.getAccess()
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "status", "error",
                    "message", e.getMessage()
            ));
        }
    }

    // POST /kakao/auth/refresh
    @PostMapping("/auth/refresh")
    public ResponseEntity<?> refresh(HttpServletRequest req, HttpServletResponse res,
                                     @RequestBody(required = false) Map<String, String> body,
                                     @RequestHeader(value = "X-Refresh", required = false) String hdrRefresh) {
        // refresh 토큰을 쿠키/헤더/바디에서 찾아본다
        String cookieRefresh = readRefreshCookie(req);
        String bodyRefresh = (body != null) ? body.get("refreshToken") : null;
        String provided = firstNonEmpty(cookieRefresh, hdrRefresh, bodyRefresh);

        if (!StringUtils.hasText(provided)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "status", "error", "message", "Refresh token missing"
            ));
        }

        var tokens = tokenService.refresh(provided,
                req.getHeader("User-Agent"), clientIp(req));

        // 새 refresh를 쿠키로 내려줌 (회전)
        setRefreshCookie(res, tokens.refresh());

        return ResponseEntity.ok(Map.of(
                "status", "success",
                "accessToken", tokens.access()
        ));
    }

    // POST /kakao/auth/logout (현재 기기만 로그아웃)
    @PostMapping("/auth/logout")
    public ResponseEntity<?> logout(HttpServletRequest req,
                                    HttpServletResponse res,
                                    @RequestBody(required = false) Map<String, String> body,
                                    @RequestHeader(value = "X-Refresh", required = false) String hdrRefresh) {
        String cookieRefresh = readRefreshCookie(req);
        String bodyRefresh = (body != null) ? body.get("refreshToken") : null;
        String provided = firstNonEmpty(cookieRefresh, hdrRefresh, bodyRefresh);

        if (!StringUtils.hasText(provided)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "status","error","message","Refresh token missing"
            ));
        }
        tokenService.revokeOneByRefresh(provided);
        clearRefreshCookie(res);

        return ResponseEntity.ok(Map.of(
                "status","success","message","Logged out on this device"
        ));
    }

    // POST /kakao/auth/logout-all (모든 기기 로그아웃)
    @PostMapping("/auth/logout-all")
    public ResponseEntity<?> logoutAll(@CurrentMember Member member,
                                       HttpServletResponse res) {
        if (member == null) {
            return ResponseEntity.status(401).body(Map.of(
                    "status","error","message","Unauthorized"
            ));
        }
        long n = tokenService.revokeAllFor(member.getId());
        clearRefreshCookie(res);
        return ResponseEntity.ok(Map.of(
                "status","success",
                "revoked", n
        ));
    }

    @GetMapping("/logout-url")
    public ResponseEntity<?> logoutUrl() {
        return ResponseEntity.ok(Map.of(
                "logoutUrl", kakaoService.buildKakaoLogoutUrl()
        ));
    }

    // ====== 유틸 메서드 ======
    private static String clientIp(HttpServletRequest req) {
        String fwd = req.getHeader("X-Forwarded-For");
        if (StringUtils.hasText(fwd)) return fwd.split(",")[0].trim();
        return req.getRemoteAddr();
    }

    private static String readRefreshCookie(HttpServletRequest req) {
        if (req.getCookies() == null) return null;
        for (Cookie c : req.getCookies()) {
            if ("refresh".equals(c.getName())) return c.getValue();
        }
        return null;
    }

    private static void setRefreshCookie(HttpServletResponse res, String refresh) {
        Cookie c = new Cookie("refresh", refresh);
        c.setHttpOnly(true);
        c.setPath("/");
        c.setMaxAge(60 * 60 * 24 * 14); // 14일
        // 운영 환경이라면: c.setSecure(true); // HTTPS 전용
        res.addCookie(c);
    }

    private static void clearRefreshCookie(HttpServletResponse res) {
        Cookie c = new Cookie("refresh", "");
        c.setPath("/");
        c.setMaxAge(0);
        res.addCookie(c);
    }

    private static String firstNonEmpty(String... vals) {
        for (String v : vals) if (StringUtils.hasText(v)) return v;
        return null;
    }
}
