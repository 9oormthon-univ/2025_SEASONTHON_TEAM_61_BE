package com.example.youthy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YouthyApplication {

	public static void main(String[] args) {
		SpringApplication.run(YouthyApplication.class, args);
	}

}
